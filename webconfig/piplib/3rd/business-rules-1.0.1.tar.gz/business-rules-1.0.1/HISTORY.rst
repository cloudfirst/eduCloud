History
-------

1.0.1
+++++
released 2016-3-16

- Fixes a packaging bug preventing 1.0.0 from being installed on some platforms.

1.0.0
+++++
released 2016-3-16

- Removes caching layer on rule decorator
